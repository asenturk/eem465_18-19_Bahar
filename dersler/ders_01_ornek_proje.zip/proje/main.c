#include "Board_LED.h"                  // ::Board Support:LED
#include "Board_Buttons.h"              // ::Board Support:Buttons

int main(void){
	
	//unsigned int btn;
	int btn;
	
	LED_Initialize();
	Buttons_Initialize();
	
	while(1){
	
	btn = Buttons_GetState();
		
		if(btn==1){
			LED_Off(3);
		}else{
			LED_On(3);
		}	
	}

	return 1;
}
