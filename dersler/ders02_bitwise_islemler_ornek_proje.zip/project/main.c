unsigned int a=0;
unsigned int b=1;

int main(void){

	
	// a sayisinin 4. bitini bir yapma
	a=a | (b << 4);
	// a sayisinin 3. bitini bir yapma
	a=a | (b << 3);
	//printf("%d: %X\n",a,a);
	
	// a sayisinin 4. bitini sifir yapalim
	a=a & ~(b << 4);
	//printf("%d: %X\n",a,a);
	
	return 0;
}
